%Movie!!!!!!!

for i=1:36
    i=int2str(i)
    t=['t',i]
    str2func(t)
end
